__version__ = '0.1.0'
import MathLib

print("hello")
print(MathLib.CalSum(2,3));
print(MathLib.CalProd(2,3));