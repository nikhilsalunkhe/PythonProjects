def CalSum(a, b): 
    return a+b

def CalProd(a, b): 
    return a*b